package es.uc3m.android.farmspot;

public interface ItemListener {
    void onItemClick(HomeCardElement item);
}
